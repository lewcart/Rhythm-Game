RhythmGameStarter 0.1.3.1

Please read the manual pdf for quick start

Developer : BennyKok
Email : itechbenny@gmail.com
Website : https://bennykok.com/

In case of any bugs and problems you have encountered with this plugin, I offer you my sincere apology and please feel free to contact me asap so I can fix it.

© 2019 BennyKok.

Song sample is a original song by BennyKok
Audio effect is from https://freesound.org/people/DWSD/sounds/183105/

Changelog>

0.1.3.1>
[Fixed] typo in the RhythmGameStarter prefab's hit level : Prefect -> Perfect

[Changed] Demo song changed to mp3 to reduce download size.

0.1.3>
[Added] SyncMode(Track, IndividualNote) for different note sync methods in TrackManager
SyncMode
: Track -> Moving the whole track with notes as child object
: IndividualNote -> Moving Individual Note, enable changing beatSize in runtime (note speed)

[Added] Tooltip in TrackManager

[Added] onComboStatusUpdate in StatsSystem

[Improved] All events are wrapped in a foldout now, to have a cleaner inspector

[Improved] Multiple typos fixed

[Changed] displayAsPrecentage in SongManager refactored to progressAsPercentage

[Fixed] HitOffset now using position offset

0.1.2>
Initial release