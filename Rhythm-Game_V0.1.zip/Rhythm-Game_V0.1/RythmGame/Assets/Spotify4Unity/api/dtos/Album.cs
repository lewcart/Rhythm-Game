﻿namespace Spotify4Unity.Dtos
{
    public class Album
    {
        public string Name { get; set; }
        public string Uri { get; set; }
        public string ImageUrl { get; set; }
    }
}
