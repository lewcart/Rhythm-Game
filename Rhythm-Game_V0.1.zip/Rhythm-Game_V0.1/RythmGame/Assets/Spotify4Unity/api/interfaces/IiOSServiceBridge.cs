﻿namespace Spotify4Unity
{
    public interface IiOSServiceBridge
    {
        void Configure(string gameObjectName, string methodName);
    }
}
