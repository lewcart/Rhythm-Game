﻿namespace Spotify4Unity.Events
{
    /// <summary>
    /// Base event class for sharing GameEvents through the EventManager
    /// </summary>
    public class GameEventBase
    {
    }
}