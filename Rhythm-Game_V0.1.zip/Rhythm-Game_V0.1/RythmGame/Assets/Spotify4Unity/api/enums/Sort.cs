﻿namespace Spotify4Unity.Enums
{
    public enum Sort
    {
        Unsorted = 0,
        Artist,
        Title,
        Album,
    }
}
