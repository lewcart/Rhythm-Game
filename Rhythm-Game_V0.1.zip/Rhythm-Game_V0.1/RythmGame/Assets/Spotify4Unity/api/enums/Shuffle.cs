﻿namespace Spotify4Unity.Enums
{
    public enum Shuffle
    {
        Disabled = 0,
        Enabled = 1,
    }
}